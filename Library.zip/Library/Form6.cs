﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form5 Form5 = new Form5();
            Form5.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Form5 Form5 = new Form5();
            Form5.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form7 Form7 = new Form7();
            Form7.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form8 Form8 = new Form8();
            Form8.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                label7.Visible = true;
            }
            if (textBox2.Text == "")
            {
                label7.Visible = true;
            }
            if (textBox3.Text == "")
            {
                label7.Visible = true;
            }
            if (textBox4.Text == "")
            {
                label7.Visible = true;
            }
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            { 
                MessageBox.Show("Издание успешно зарегистрировано");
        }
        }
    }
}
